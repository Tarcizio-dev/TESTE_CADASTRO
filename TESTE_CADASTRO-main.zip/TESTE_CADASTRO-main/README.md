# TESTE_CADASTRO
Esse é um teste realizando cadastro de usuario, preenchendo todos os campos obrigatorios de forma automatizada utilizando Cypress
